# NAE Teacher Training Registration Portal 2026

A Vercel-ready hybrid registration portal using the uploaded school, nomination and training-session data, with Jotform as the normalized submission/reporting layer.

## Business rules implemented

- School selection uses the full 286-school master list.
- The school selector is a client-side searchable dropdown: the 286 school names/ESIS values are loaded once, then filtering is instant while the user types.
- School Coordinator details come from `schools-master.csv`. When a coordinator is already listed, the portal displays only the coordinator name; email and phone remain server-side and are never sent to the browser.
- If a school has no listed coordinator, the school is asked to enter the School Coordinator name, email and optional phone number before continuing.
- The server also enforces the listed coordinator data for schools that have it, so browser-side edits cannot replace the coordinator stored in the master list.
- Selected school loads only that school's nomination roster. Schools with no nominations remain eligible and can add teachers in the Additional Teachers step.
- Abu Dhabi schools: Literary Arts, Digital Arts and Visual Arts route to Abu Dhabi sessions.
- Al Ain schools: Literary Arts, Digital Arts and Visual Arts route to Al Ain sessions.
- Al Dhafra schools: the teacher chooses Abu Dhabi or Al Ain independently for Literary Arts, Digital Arts and Visual Arts.
- Performing Arts always routes to the Abu Dhabi session for all school regions.
- Oral History is open to every teacher and is always in Abu Dhabi.
- Oral History allows selection of 24 September 2026, 1 October 2026, or both.
- Applied Arts is not displayed as a training pathway. Existing Applied Arts nominations are marked as routed to Oral History.
- Teachers can hold multiple pathway registrations.
- Additional teachers can be added dynamically and may register for any available training pathway.
- Final Jotform storage is normalized: one Jotform submission per teacher per selected session.
- After successful submission the portal displays the receipt only; there is no "Register another school" button.

## Created Jotform

Form title: `NAE Teacher Training Registration Records 2026`

Form ID is configured in `.env.example`.

## Deploy to Vercel

1. Open this project folder in VS Code.
2. In Jotform, create a private API key under **My Account > API**.
3. Add these Vercel environment variables:
   - `JOTFORM_API_KEY` = your private Jotform API key
   - `JOTFORM_FORM_ID` = `262592775577071`
4. Deploy and test before distributing the public link.

Do **not** put the Jotform API key in `public/app.js` or any browser-visible file.

## Data files

`data/registration-data.json` is built from:

- `schools-master.csv` — authoritative 286-school list and School Coordinator details, updated from `schools (44).csv`
- `TOT Nominations.xlsx` — existing teacher nominations
- `NAE Teacher Training Sessions_Final Schedule(1).xlsx` — training schedule

Current school-list summary:

- 286 schools total
- 220 schools with existing nominations
- 66 schools without nominations
- 278 schools with a listed School Coordinator name and email
- 8 schools without a listed School Coordinator; these schools enter their coordinator details in the portal

The JSON remains outside `public/` and is loaded by server-side Vercel functions.

## API routes

- `/api/schools` — returns the school-name/ESIS/region list used by the instant searchable dropdown. It does not return teacher rosters or coordinator details.
- `/api/school?esis=` — returns the selected school roster plus only the listed coordinator name/status. Coordinator email/phone and nominated-teacher contact details remain server-side.
- `/api/config` — returns non-sensitive training-session configuration.
- `/api/register` — validates business rules server-side and creates normalized Jotform submission records.

## Important Jotform API behavior

Jotform API-created submissions are stored as submissions, but API-created submissions may not trigger the same notification/integration behavior as a respondent submitting the hosted Jotform directly. If confirmation emails are required, add a server-side email provider or separate notification workflow after `/api/register` succeeds.

## Privacy / production hardening

School search exposes only School ESIS, School Name and Region. After selection, the browser receives the nomination roster needed for confirmation and only the coordinator name/status. Coordinator email/phone and nominated-teacher contact details are retained server-side and enriched into Jotform only at submission time. For a public production launch, consider adding a school access code or authenticated school link before returning the roster if teacher names should not be discoverable by someone who knows a School ESIS.


## UX update

- Coordinator email and phone are hidden for schools that already have a coordinator on record.
- The interface uses a clearer four-step progress flow, live school/session counts, loading feedback, inline status cues, selectable cards, responsive layouts, and non-blocking toast validation messages.
- The searchable school dropdown remains client-side after the initial directory load for fast filtering.
