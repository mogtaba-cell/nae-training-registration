const state={school:null,schoolList:[],sessions:[],nominated:[],additional:[],activeSchoolResult:-1};
const $=s=>document.querySelector(s); const $$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmtDate=s=>new Intl.DateTimeFormat('en-GB',{day:'numeric',month:'short',year:'numeric'}).format(new Date(`${s}T12:00:00`));
const byPath=p=>state.sessions.filter(s=>s.pathway===p);
function sessionFor(path,region,choice){
  if(path==='Performing Arts') return byPath(path).find(s=>s.region==='Abu Dhabi');
  if(path==='Oral History') return null;
  const r=region==='Al Dhafra'?choice:region;
  return byPath(path).find(s=>s.region===r);
}
function showStep(n){const current=Math.min(n,4);$$('.panel').forEach(p=>p.classList.toggle('active',p.dataset.panel===String(n)));$$('.step').forEach(s=>{const step=Number(s.dataset.step);s.classList.toggle('active',step===current);s.classList.toggle('complete',step<current);});window.scrollTo({top:0,behavior:'smooth'});}
function toast(message,type='info'){const host=$('#toastHost');if(!host)return;const el=document.createElement('div');el.className=`toast ${type==='error'?'error-toast':''}`;el.innerHTML=`<div><strong>${type==='error'?'Please check':'Updated'}</strong><small>${esc(message)}</small></div>`;host.appendChild(el);setTimeout(()=>el.remove(),3600);}

async function bootstrap(){
  try{
    const [config,schools]=await Promise.all([
      fetch('/api/config').then(r=>{if(!r.ok)throw new Error('Unable to load session configuration.');return r.json();}),
      fetch('/api/schools').then(r=>{if(!r.ok)throw new Error('Unable to load schools.');return r.json();})
    ]);
    state.sessions=config.sessions||[];
    state.schoolList=schools||[];
    $('#schoolSearch').placeholder='Start typing a school name or ESIS…';
    $('#schoolLoadStatus').textContent=`${state.schoolList.length} schools ready to search`;
  }catch(e){
    $('#schoolSearch').placeholder='Unable to load schools';
    $('#schoolSearch').disabled=true;
    $('#schoolLoadStatus').textContent='School directory unavailable';
    $('#schoolResults').innerHTML=`<div class="result empty-result">${esc(e.message)}</div>`;
    $('#schoolResults').classList.remove('hidden');
  }
}
bootstrap();

function exactSelectedText(){return state.school?`${state.school.schoolEsis} — ${state.school.schoolName}`:'';}
function clearSelectedSchool(){
  state.school=null; state.nominated=[]; state.additional=[];
  $('#selectedSchool').classList.add('hidden');
  $('#selectedSchool').innerHTML='';
  $('#contactFields').classList.add('hidden');
  $('#coordinatorView').classList.add('hidden');
  $('#manualCoordinator').classList.add('hidden');
  $('#contactName').value=''; $('#contactEmail').value=''; $('#contactPhone').value='';
  $('#toTeachers').disabled=true;
  $('#schoolActionHint').textContent='Select a school to continue';
}
function rankSchools(q){
  const needle=q.trim().toLowerCase();
  if(!needle) return state.schoolList.slice(0,30);
  return state.schoolList
    .map(s=>{
      const name=s.schoolName.toLowerCase(), esis=s.schoolEsis.toLowerCase();
      let score=99;
      if(esis===needle) score=0;
      else if(esis.startsWith(needle)) score=1;
      else if(name.startsWith(needle)) score=2;
      else if(esis.includes(needle)) score=3;
      else if(name.includes(needle)) score=4;
      return {s,score};
    })
    .filter(x=>x.score<99)
    .sort((a,b)=>a.score-b.score||a.s.schoolName.localeCompare(b.s.schoolName))
    .slice(0,30)
    .map(x=>x.s);
}
function openSchoolResults(){
  $('#schoolResults').classList.remove('hidden');
  $('#schoolSearch').setAttribute('aria-expanded','true');
}
function closeSchoolResults(){
  $('#schoolResults').classList.add('hidden');
  $('#schoolSearch').setAttribute('aria-expanded','false');
  state.activeSchoolResult=-1;
}
function renderSchoolResults(q){
  const box=$('#schoolResults');
  const list=rankSchools(q);
  state.activeSchoolResult=-1;
  box.innerHTML=list.length?list.map((s,i)=>`<div class="result" role="option" id="school-option-${i}" data-esis="${esc(s.schoolEsis)}" aria-selected="false"><strong>${esc(s.schoolEsis)} — ${esc(s.schoolName)}</strong><small>${esc(s.region)}</small></div>`).join(''):'<div class="result empty-result">No matching schools found</div>';
  openSchoolResults();
  box.querySelectorAll('[data-esis]').forEach(el=>el.addEventListener('mousedown',e=>{e.preventDefault();selectSchool(el.dataset.esis);}));
}
function setActiveSchoolResult(next){
  const items=$$('#schoolResults [data-esis]');
  if(!items.length)return;
  state.activeSchoolResult=Math.max(0,Math.min(next,items.length-1));
  items.forEach((el,i)=>{const active=i===state.activeSchoolResult;el.classList.toggle('active',active);el.setAttribute('aria-selected',String(active));});
  const active=items[state.activeSchoolResult];
  $('#schoolSearch').setAttribute('aria-activedescendant',active.id);
  active.scrollIntoView({block:'nearest'});
}
$('#schoolSearch').addEventListener('focus',e=>renderSchoolResults(e.target.value===exactSelectedText()?'':e.target.value));
$('#schoolSearch').addEventListener('input',e=>{
  if(state.school && e.target.value!==exactSelectedText()) clearSelectedSchool();
  renderSchoolResults(e.target.value);
});
$('#schoolSearch').addEventListener('keydown',e=>{
  const visible=!$('#schoolResults').classList.contains('hidden');
  const items=$$('#schoolResults [data-esis]');
  if(e.key==='ArrowDown'){e.preventDefault();if(!visible)renderSchoolResults(e.currentTarget.value);setActiveSchoolResult(state.activeSchoolResult+1);}
  else if(e.key==='ArrowUp'){e.preventDefault();setActiveSchoolResult(state.activeSchoolResult<=0?0:state.activeSchoolResult-1);}
  else if(e.key==='Enter'&&visible&&state.activeSchoolResult>=0&&items[state.activeSchoolResult]){e.preventDefault();selectSchool(items[state.activeSchoolResult].dataset.esis);}
  else if(e.key==='Escape'){closeSchoolResults();}
});
document.addEventListener('click',e=>{if(!e.target.closest('.search-wrap'))closeSchoolResults();});

function hasListedCoordinator(){
  const c=state.school?.schoolCoordinator;
  return Boolean(c?.listed && c?.name);
}
function renderCoordinator(){
  const c=state.school?.schoolCoordinator;
  $('#contactFields').classList.remove('hidden');
  if(hasListedCoordinator()){
    $('#manualCoordinator').classList.add('hidden');
    $('#coordinatorView').innerHTML=`<div class="coordinator-card"><div class="coordinator-heading"><div class="coordinator-main"><div class="coordinator-avatar">✓</div><div><span class="mini-label">School Coordinator on record</span><h3>${esc(c.name)}</h3></div></div><span class="badge verified">Verified</span></div><p>Contact details are kept private and are not displayed in this portal.</p></div>`;
    $('#coordinatorView').classList.remove('hidden');
  }else{
    $('#coordinatorView').classList.add('hidden');
    $('#coordinatorView').innerHTML='';
    $('#manualCoordinator').classList.remove('hidden');
  }
}
async function selectSchool(esis){
  closeSchoolResults();
  $('#toTeachers').disabled=true;
  $('#schoolSearch').parentElement.classList.add('loading');
  $('#schoolActionHint').textContent='Loading school details…';
  try{
    const r=await fetch(`/api/school?esis=${encodeURIComponent(esis)}`);
    if(!r.ok)throw new Error('Unable to load this school. Please try again.');
    state.school=await r.json();
    state.nominated=state.school.teachers.map(t=>({...t,registrations:{}}));
    state.additional=[];
    $('#schoolSearch').value=exactSelectedText();
    const nomineeCount=state.nominated.length;
    $('#selectedSchool').innerHTML=`<div class="selected-main"><div class="selected-check">✓</div><div><h3>${esc(state.school.schoolName)}</h3><p>${esc(state.school.schoolEsis)}</p></div></div><div class="school-chips"><span class="school-chip">${esc(state.school.region)} region</span><span class="school-chip">${nomineeCount} nominated teacher${nomineeCount===1?'':'s'}</span></div>`;
    $('#selectedSchool').classList.remove('hidden');
    renderCoordinator();
    $('#toTeachers').disabled=false;
    $('#schoolActionHint').textContent=nomineeCount?`${nomineeCount} nominated teacher${nomineeCount===1?'':'s'} found`:'No nominees found — you can add teachers in Step 3';
  }catch(e){
    toast(e.message,'error');
    $('#schoolActionHint').textContent='Select a school to continue';
  }finally{
    $('#schoolSearch').parentElement.classList.remove('loading');
  }
}
function getSchoolContact(){
  if(hasListedCoordinator()){
    const c=state.school.schoolCoordinator;
    return {name:c.name||'',email:'',phone:''};
  }
  return {name:$('#contactName').value.trim(),email:$('#contactEmail').value.trim(),phone:$('#contactPhone').value.trim()};
}
$('#toTeachers').onclick=()=>{
  if(!state.school)return;
  if(!hasListedCoordinator()){
    const c=getSchoolContact();
    if(!c.name||!c.email||!$('#contactEmail').checkValidity()){toast('Please enter a valid School Coordinator name and email.','error');return;}
  }
  renderNominated();showStep(2);
};
$$('[data-go]').forEach(b=>b.onclick=()=>{const n=Number(b.dataset.go);if(n===3) renderAdditional();showStep(n)});

function sessionText(s){return s?`${fmtDate(s.date)} • ${esc(s.region)} • ${esc(s.venue)} • ${esc(s.time)}`:'Session unavailable';}
function dhafraSelect(ti,path,type='nom'){return `<select class="region-choice" data-kind="${type}" data-ti="${ti}" data-path="${esc(path)}"><option value="">Choose training region…</option><option>Abu Dhabi</option><option>Al Ain</option></select>`;}
function renderNominated(){const root=$('#nominatedTeachers');if(!state.nominated.length){root.innerHTML=`<div class="notice empty-roster"><strong>No nominated teachers were found for this school.</strong><br>This school is still eligible to register teachers. Continue to <strong>Additional teachers</strong> and add the teachers and pathways they would like to attend.</div>`;return;}root.innerHTML=state.nominated.map((t,i)=>{
  const badges=t.originalPathways.map(p=>`<span class="badge ${p==='Applied Arts'?'route':''}">${esc(p)}${p==='Applied Arts'?' → Oral History':''}</span>`).join('');
  const cards=t.nominatedTrainingPathways.map(p=>{
    const isD=state.school.region==='Al Dhafra' && ['Literary Arts','Digital Arts','Visual Arts'].includes(p); const s=isD?null:sessionFor(p,state.school.region);
    return `<div class="path-card"><div class="path-row"><div><h4>${esc(p)}</h4><div class="session" data-session-label="nom-${i}-${esc(p)}">${isD?'Select Abu Dhabi or Al Ain to see the session.':sessionText(s)}</div>${isD?dhafraSelect(i,p):''}</div><label class="checkline"><input type="checkbox" data-confirm="nom" data-ti="${i}" data-path="${esc(p)}" ${isD?'disabled':''}> Confirm attendance</label></div></div>`;
  }).join('');
  const oral=byPath('Oral History').map(s=>`<label class="oral-option"><input type="checkbox" data-oral="nom" data-ti="${i}" value="${esc(s.id)}"> <span><strong>${fmtDate(s.date)}</strong> — ${esc(s.venue)}<br><small>${esc(s.time)}</small></span></label>`).join('');
  return `<article class="teacher-card"><div class="teacher-title"><div><h3>${esc(t.teacherName)}</h3><div class="muted">Teacher eSIS: ${esc(t.teacherEsis)}</div><div class="badges">${badges}</div></div></div>${cards}<div class="path-card"><h4>Oral History <span class="badge">Available to all</span></h4><div class="session">Select one or both Abu Dhabi sessions.</div><div class="oral-options">${oral}</div></div></article>`;
}).join('');wireNominated();}
function wireNominated(){
  $$('[data-kind="nom"]').forEach(sel=>sel.onchange=()=>{const i=+sel.dataset.ti,p=sel.dataset.path,s=sessionFor(p,state.school.region,sel.value),label=document.querySelector(`[data-session-label="nom-${i}-${CSS.escape(p)}"]`),cb=document.querySelector(`[data-confirm="nom"][data-ti="${i}"][data-path="${CSS.escape(p)}"]`); if(label)label.innerHTML=sessionText(s);cb.disabled=!s;if(!s)cb.checked=false;state.nominated[i].registrations[p]={confirmed:cb.checked,trainingRegion:sel.value};});
  $$('[data-confirm="nom"]').forEach(cb=>cb.onchange=()=>{const i=+cb.dataset.ti,p=cb.dataset.path;const current=state.nominated[i].registrations[p]||{};current.confirmed=cb.checked;if(state.school.region==='Al Dhafra'){const sel=document.querySelector(`[data-kind="nom"][data-ti="${i}"][data-path="${CSS.escape(p)}"]`);current.trainingRegion=sel?.value||'';}state.nominated[i].registrations[p]=current;});
  $$('[data-oral="nom"]').forEach(cb=>cb.onchange=()=>{const i=+cb.dataset.ti;state.nominated[i].registrations['Oral History']={sessionIds:$$(`[data-oral="nom"][data-ti="${i}"]:checked`).map(x=>x.value)};});
}

$('#addTeacher').onclick=()=>{state.additional.push({id:crypto.randomUUID(),teacherEsis:'',teacherName:'',teacherEmail:'',teacherPhone:'',paths:[],registrations:{}});renderAdditional();};
function renderAdditional(){const root=$('#additionalTeachers');if(!state.additional.length){root.innerHTML=`<div class="empty-additional"><div><strong>No additional teachers added yet.</strong><span>This step is optional. Use the button below if the school wants to register more teachers.</span></div></div>`;return;}root.innerHTML=state.additional.map((t,i)=>`<article class="teacher-card additional-card" data-add-card="${i}"><div class="teacher-title"><h3>Additional teacher ${i+1}</h3><button class="remove" data-remove="${i}">Remove</button></div><div class="grid two"><label>Teacher name<input data-add-field="teacherName" data-i="${i}" value="${esc(t.teacherName)}"></label><label>Teacher eSIS<input data-add-field="teacherEsis" data-i="${i}" value="${esc(t.teacherEsis)}"></label><label>Email<input type="email" data-add-field="teacherEmail" data-i="${i}" value="${esc(t.teacherEmail)}"></label><label>Phone<input data-add-field="teacherPhone" data-i="${i}" value="${esc(t.teacherPhone)}"></label></div><div class="path-card"><h4>Select pathway(s)</h4><div class="path-picker">${['Literary Arts','Digital Arts','Performing Arts','Visual Arts','Oral History'].map(p=>`<label><input type="checkbox" data-add-path="${i}" value="${esc(p)}" ${t.paths.includes(p)?'checked':''}>${esc(p)}</label>`).join('')}</div><div data-add-sessions="${i}">${renderAddSessionControls(t,i)}</div></div></article>`).join('');wireAdditional();}
function renderAddSessionControls(t,i){return t.paths.map(p=>{
  if(p==='Oral History')return `<div class="path-card"><h4>Oral History sessions</h4><div class="session">Select one or both.</div><div class="oral-options">${byPath('Oral History').map(s=>`<label class="oral-option"><input type="checkbox" data-oral="add" data-ti="${i}" value="${esc(s.id)}" ${(t.registrations[p]?.sessionIds||[]).includes(s.id)?'checked':''}><span><strong>${fmtDate(s.date)}</strong> — ${esc(s.venue)}<br><small>${esc(s.time)}</small></span></label>`).join('')}</div></div>`;
  const isD=state.school.region==='Al Dhafra'&&['Literary Arts','Digital Arts','Visual Arts'].includes(p);const choice=t.registrations[p]?.trainingRegion||'';const s=isD?sessionFor(p,state.school.region,choice):sessionFor(p,state.school.region);
  return `<div class="path-card"><h4>${esc(p)}</h4><div class="session" data-session-label="add-${i}-${esc(p)}">${isD&&!choice?'Choose a training region.':sessionText(s)}</div>${isD?`<select class="region-choice" data-kind="add" data-ti="${i}" data-path="${esc(p)}"><option value="">Choose training region…</option><option ${choice==='Abu Dhabi'?'selected':''}>Abu Dhabi</option><option ${choice==='Al Ain'?'selected':''}>Al Ain</option></select>`:''}</div>`;
}).join('');}
function wireAdditional(){
  $$('[data-remove]').forEach(b=>b.onclick=()=>{state.additional.splice(+b.dataset.remove,1);renderAdditional();});
  $$('[data-add-field]').forEach(inp=>inp.oninput=()=>state.additional[+inp.dataset.i][inp.dataset.addField]=inp.value);
  $$('[data-add-path]').forEach(cb=>cb.onchange=()=>{const i=+cb.dataset.addPath,t=state.additional[i];t.paths=$$(`[data-add-path="${i}"]:checked`).map(x=>x.value);for(const p of Object.keys(t.registrations))if(!t.paths.includes(p))delete t.registrations[p];document.querySelector(`[data-add-sessions="${i}"]`).innerHTML=renderAddSessionControls(t,i);wireAdditionalNested();});
  wireAdditionalNested();
}
function wireAdditionalNested(){
  $$('[data-kind="add"]').forEach(sel=>sel.onchange=()=>{const i=+sel.dataset.ti,p=sel.dataset.path,t=state.additional[i];t.registrations[p]={...(t.registrations[p]||{}),trainingRegion:sel.value};const label=document.querySelector(`[data-session-label="add-${i}-${CSS.escape(p)}"]`);if(label)label.innerHTML=sessionText(sessionFor(p,state.school.region,sel.value));});
  $$('[data-oral="add"]').forEach(cb=>cb.onchange=()=>{const i=+cb.dataset.ti;state.additional[i].registrations['Oral History']={sessionIds:$$(`[data-oral="add"][data-ti="${i}"]:checked`).map(x=>x.value)};});
}

$('#toReview').onclick=()=>{const err=validateAdditional();if(err){toast(err,'error');return;}renderReview();showStep(4);};
function validateAdditional(){for(let i=0;i<state.additional.length;i++){const t=state.additional[i];if(!t.teacherName.trim()||!t.teacherEsis.trim())return `Additional teacher ${i+1}: name and Teacher eSIS are required.`;if(!t.paths.length)return `Additional teacher ${i+1}: select at least one pathway.`;for(const p of t.paths){if(p==='Oral History'&&!(t.registrations[p]?.sessionIds||[]).length)return `Additional teacher ${i+1}: select at least one Oral History date.`;if(state.school.region==='Al Dhafra'&&['Literary Arts','Digital Arts','Visual Arts'].includes(p)&&!t.registrations[p]?.trainingRegion)return `Additional teacher ${i+1}: choose Abu Dhabi or Al Ain for ${p}.`;}}return '';}
function collectPayload(){const teachers=[];
  state.nominated.forEach(t=>{const regs=[];for(const p of t.nominatedTrainingPathways){const r=t.registrations[p];if(r?.confirmed)regs.push({pathway:p,trainingRegion:r.trainingRegion||''});}const oral=t.registrations['Oral History'];if(oral?.sessionIds?.length)regs.push({pathway:'Oral History',sessionIds:oral.sessionIds});if(regs.length)teachers.push({registrationType:'Nominated Teacher',teacherEsis:t.teacherEsis,teacherName:t.teacherName,teacherEmail:t.email,teacherPhone:t.phone,registrations:regs});});
  state.additional.forEach(t=>{const regs=t.paths.map(p=>p==='Oral History'?{pathway:p,sessionIds:t.registrations[p]?.sessionIds||[]}:{pathway:p,trainingRegion:t.registrations[p]?.trainingRegion||''});teachers.push({registrationType:'Additional Teacher',teacherEsis:t.teacherEsis,teacherName:t.teacherName,teacherEmail:t.teacherEmail,teacherPhone:t.teacherPhone,registrations:regs});});
  const c=getSchoolContact();
  return {schoolEsis:state.school.schoolEsis,contactName:c.name,contactEmail:c.email,contactPhone:c.phone,teachers};
}
function expandForReview(payload){const out=[];payload.teachers.forEach(t=>t.registrations.forEach(r=>{if(r.pathway==='Oral History'){(r.sessionIds||[]).forEach(id=>{const s=state.sessions.find(x=>x.id===id);if(s)out.push({teacher:t.teacherName,type:t.registrationType,path:r.pathway,s});});}else{const s=sessionFor(r.pathway,state.school.region,r.trainingRegion);if(s)out.push({teacher:t.teacherName,type:t.registrationType,path:r.pathway,s});}}));return out;}
function renderReview(){const payload=collectPayload(),rows=expandForReview(payload);const grouped={};rows.forEach(r=>{const k=r.s.id;(grouped[k]??={s:r.s,rows:[]}).rows.push(r);});$('#review').innerHTML=`<div class="review-school"><strong>${esc(state.school.schoolName)}</strong><br>${esc(state.school.schoolEsis)} • ${esc(state.school.region)}<span class="coordinator-review">School Coordinator: ${esc(payload.contactName)}</span></div>${rows.length?Object.values(grouped).sort((a,b)=>a.s.date.localeCompare(b.s.date)).map(g=>`<div class="review-group"><h3>${esc(g.s.pathway)} — ${fmtDate(g.s.date)}</h3><div class="session">${esc(g.s.region)} • ${esc(g.s.venue)} • ${esc(g.s.time)}</div>${g.rows.map(r=>`<div class="review-entry"><strong>${esc(r.teacher)}</strong> <span class="badge">${esc(r.type)}</span></div>`).join('')}</div>`).join(''):'<div class="notice"><span class="notice-icon">!</span><div>No sessions are selected yet. Go back and confirm at least one teacher/session.</div></div>'}`;$('#submitRegistration').disabled=!$('#finalConfirm').checked||!rows.length;}
$('#finalConfirm').onchange=()=>{const rows=expandForReview(collectPayload());$('#submitRegistration').disabled=!$('#finalConfirm').checked||!rows.length;};
$('#submitRegistration').onclick=async()=>{const btn=$('#submitRegistration');const error=$('#submitError');error.classList.add('hidden');btn.disabled=true;btn.textContent='Submitting…';btn.classList.add('submitting');try{const r=await fetch('/api/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(collectPayload())});const body=await r.json();if(!r.ok)throw new Error(body.error||'Submission failed.');$('#receipt').innerHTML=`School submission ID: <strong>${esc(body.schoolSubmissionId)}</strong><br>Session records created: <strong>${body.recordsCreated}</strong>`;showStep(5);}catch(e){error.textContent=e.message;error.classList.remove('hidden');btn.disabled=false;btn.textContent='Submit registration';toast(e.message,'error');}finally{btn.classList.remove('submitting');}};
