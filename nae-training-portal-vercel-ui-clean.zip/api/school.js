const {getSchool} = require('./_lib');

module.exports = (req,res) => {
  const school=getSchool(req.query.esis);
  if (!school) return res.status(404).json({error:'School not found'});

  const listedCoordinator = school.schoolCoordinator && school.schoolCoordinator.name && school.schoolCoordinator.email;
  const safeSchool = {
    schoolEsis: school.schoolEsis,
    schoolName: school.schoolName,
    region: school.region,
    schoolCoordinator: listedCoordinator
      ? {name: school.schoolCoordinator.name, listed: true}
      : {listed: false},
    teachers: (school.teachers || []).map(t => ({
      teacherEsis: t.teacherEsis,
      teacherName: t.teacherName,
      originalPathways: t.originalPathways || [],
      nominatedTrainingPathways: t.nominatedTrainingPathways || [],
      appliedArtsRoutedToOralHistory: Boolean(t.appliedArtsRoutedToOralHistory)
    }))
  };

  // Coordinator email/phone and nominated-teacher contact details deliberately
  // stay server-side. The registration endpoint enriches the final Jotform records.
  res.setHeader('Cache-Control','no-store');
  res.status(200).json(safeSchool);
};
