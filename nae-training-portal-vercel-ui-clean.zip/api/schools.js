const {data} = require('./_lib');
module.exports = (req,res) => {
  const q=String(req.query.q||'').trim().toLowerCase();
  let items=data.schools.map(s=>({schoolEsis:s.schoolEsis,schoolName:s.schoolName,region:s.region}));
  if(q){
    items=items.filter(s=>s.schoolName.toLowerCase().includes(q)||s.schoolEsis.toLowerCase().includes(q));
  }
  items.sort((a,b)=>a.schoolName.localeCompare(b.schoolName));
  res.setHeader('Cache-Control','public, max-age=300, s-maxage=300');
  res.status(200).json(items);
};
