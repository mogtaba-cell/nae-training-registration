# NAE Teacher Training Registration Portal 2026

A Vercel-ready hybrid registration portal using the uploaded nomination and training-session workbooks, with Jotform as the normalized submission/reporting layer.

## Business rules implemented

- School search by School Name or School ESIS across the full 286-school master list.
- Selected school loads only that school's nomination roster. Schools with no nominations remain eligible and can add teachers in the Additional Teachers step.
- Abu Dhabi schools: Literary Arts, Digital Arts and Visual Arts route to Abu Dhabi sessions.
- Al Ain schools: Literary Arts, Digital Arts and Visual Arts route to Al Ain sessions.
- Al Dhafra schools: the teacher chooses Abu Dhabi or Al Ain independently for Literary Arts, Digital Arts and Visual Arts.
- Performing Arts always routes to the Abu Dhabi session for all school regions.
- Oral History is open to every teacher and is always in Abu Dhabi.
- Oral History allows selection of 24 September 2026, 1 October 2026, or both.
- Applied Arts is not displayed as a training pathway. Existing Applied Arts nominations are marked as routed to Oral History.
- Teachers can hold multiple pathway registrations.
- Additional teachers can be added dynamically and may register for any available training pathway.
- Final Jotform storage is normalized: one Jotform submission per teacher per selected session. This keeps filtering and attendance reporting simple.

## Created Jotform

Form title: `NAE Teacher Training Registration Records 2026`

Form ID is configured in `.env.example`.

## Deploy to Vercel

1. Upload this project folder to a Git repository, or import it directly to Vercel.
2. In Jotform, create a private API key under **My Account > API**.
3. In the Vercel project's **Settings > Environment Variables**, add:
   - `JOTFORM_API_KEY` = your private Jotform API key
   - `JOTFORM_FORM_ID` = `262592775577071`
4. Deploy.
5. Open the deployed URL and test with a school from each region before distributing it.

Do **not** put the Jotform API key in `public/app.js` or any browser-visible file.

## Data files

`data/registration-data.json` was generated from:

- `schools (46).csv` — authoritative master school list (286 schools)
- `TOT Nominations.xlsx` — existing teacher nominations
- `NAE Teacher Training Sessions_Final Schedule(1).xlsx` — training schedule

There are 220 schools with existing nominations and 66 schools with no nominations. Schools with no nominations can still add teachers and register them for eligible pathways.

The JSON remains outside `public/` and is loaded by server-side Vercel functions.

## API routes

- `/api/schools?q=` — school search suggestions; does not return teacher rosters.
- `/api/school?esis=` — returns the selected school's roster.
- `/api/config` — returns non-sensitive training-session configuration.
- `/api/register` — validates business rules server-side and creates normalized Jotform submission records.

## Important Jotform API behavior

Jotform API-created submissions are stored as submissions, but Jotform support documentation notes that API-created submissions may not trigger the same email notifications/integrations as a respondent submitting the hosted Jotform directly. If confirmation emails are required, add a server-side email provider or a separate notification workflow after `/api/register` succeeds.

## Privacy / production hardening

School search itself exposes only School ESIS, School Name and Region. Teacher records are requested only after a school is selected. For a production public launch, consider adding a school access code or authenticated school link before returning the roster, especially if teacher names/contact data should not be discoverable by someone who knows a School ESIS.
