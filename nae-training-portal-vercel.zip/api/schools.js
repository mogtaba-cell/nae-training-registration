const {data} = require('./_lib');
module.exports = (req,res) => {
  const q=String(req.query.q||'').trim().toLowerCase();
  if (q.length < 2) return res.status(200).json([]);
  const items=data.schools.filter(s=>s.schoolName.toLowerCase().includes(q)||s.schoolEsis.toLowerCase().includes(q)).slice(0,20).map(s=>({schoolEsis:s.schoolEsis,schoolName:s.schoolName,region:s.region}));
  res.setHeader('Cache-Control','private, max-age=60');
  res.status(200).json(items);
};
