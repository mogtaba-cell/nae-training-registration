const {getSchool} = require('./_lib');
module.exports = (req,res) => {
  const school=getSchool(req.query.esis);
  if (!school) return res.status(404).json({error:'School not found'});
  res.setHeader('Cache-Control','no-store');
  res.status(200).json(school);
};
