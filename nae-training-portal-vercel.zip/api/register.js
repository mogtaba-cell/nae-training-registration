const crypto=require('crypto');
const {getSchool,expectedSessions,cleanText,submitJotformRecord}=require('./_lib');

function id(prefix){return `${prefix}-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;}
function validateEmail(v){return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v||''));}

module.exports=async(req,res)=>{
  if(req.method!=='POST') return res.status(405).json({error:'POST required'});
  try{
    const b=typeof req.body==='string'?JSON.parse(req.body):req.body;
    const school=getSchool(b.schoolEsis);
    if(!school) return res.status(400).json({error:'Invalid school.'});
    const contactName=cleanText(b.contactName,120), contactEmail=cleanText(b.contactEmail,180), contactPhone=cleanText(b.contactPhone,50);
    if(!contactName||!validateEmail(contactEmail)) return res.status(400).json({error:'A valid school contact name and email are required.'});
    const submittedTeachers=Array.isArray(b.teachers)?b.teachers:[];
    if(!submittedTeachers.length) return res.status(400).json({error:'No teacher registrations were selected.'});
    const schoolSubmissionId=id('SCHOOL');
    const records=[];
    const roster=new Map(school.teachers.map(t=>[String(t.teacherEsis),t]));
    for(const t of submittedTeachers){
      const registrationType=t.registrationType==='Additional Teacher'?'Additional Teacher':'Nominated Teacher';
      const rosterTeacher=registrationType==='Nominated Teacher'?roster.get(String(t.teacherEsis)):null;
      if(registrationType==='Nominated Teacher'&&!rosterTeacher) throw new Error(`Teacher ${cleanText(t.teacherName,100)} is not in this school's nomination roster.`);
      const teacherName=cleanText(rosterTeacher?.teacherName||t.teacherName,150);
      const teacherEsis=cleanText(rosterTeacher?.teacherEsis||t.teacherEsis,80);
      const teacherEmail=cleanText(rosterTeacher?.email||t.teacherEmail,180);
      const teacherPhone=cleanText(rosterTeacher?.phone||t.teacherPhone,50);
      if(!teacherName||!teacherEsis) throw new Error('Each teacher requires a name and Teacher eSIS.');
      const registrations=Array.isArray(t.registrations)?t.registrations:[];
      for(const reg of registrations){
        const pathway=cleanText(reg.pathway,80);
        let sessions=[];
        if(pathway==='Oral History'){
          const selected=Array.isArray(reg.sessionIds)?reg.sessionIds:[];
          const allowed=expectedSessions('Oral History',school.region);
          sessions=allowed.filter(s=>selected.includes(s.id));
          if(!sessions.length) throw new Error(`Select at least one Oral History date for ${teacherName}.`);
        } else {
          if(registrationType==='Nominated Teacher' && !rosterTeacher.nominatedTrainingPathways.includes(pathway)) throw new Error(`${teacherName} is not nominated for ${pathway}.`);
          const expected=expectedSessions(pathway,school.region,cleanText(reg.trainingRegion,50));
          if(expected.length!==1) throw new Error(`Unable to resolve a valid ${pathway} session for ${teacherName}.`);
          sessions=expected;
        }
        for(const session of sessions){
          const orig = registrationType==='Nominated Teacher'
            ? (pathway==='Oral History' && rosterTeacher.appliedArtsRoutedToOralHistory ? 'Applied Arts' : (rosterTeacher.originalPathways.includes(pathway)?pathway:'Not Originally Nominated'))
            : 'Not Originally Nominated';
          records.push({schoolEsis:school.schoolEsis,schoolName:school.schoolName,schoolRegion:school.region,contactName,contactEmail,contactPhone,teacherEsis,teacherName,teacherEmail,teacherPhone,registrationType,originalNominationPathway:orig,pathway,trainingRegion:session.region,sessionDate:session.date,venue:session.venue,sessionTime:session.time,portalRegistrationId:id('REG'),schoolSubmissionId,notes:cleanText(reg.notes,500)});
        }
      }
    }
    if(!records.length) return res.status(400).json({error:'No confirmed sessions were selected.'});
    const results=[];
    for(const record of records){ results.push(await submitJotformRecord(record)); }
    res.status(200).json({ok:true,schoolSubmissionId,recordsCreated:records.length});
  }catch(e){console.error(e);res.status(500).json({error:e.message||'Registration failed.'});}
};
