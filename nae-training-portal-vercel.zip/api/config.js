const {data} = require('./_lib');
module.exports=(req,res)=>res.status(200).json({sessions:data.sessions,pathways:['Oral History','Literary Arts','Digital Arts','Performing Arts','Visual Arts']});
