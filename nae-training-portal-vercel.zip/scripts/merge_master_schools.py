import csv
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / 'data' / 'registration-data.json'
MASTER_CSV = ROOT / 'data' / 'schools-master.csv'


def norm_id(value):
    value = str(value or '').strip().upper()
    return re.sub(r'AD$', '', value)


def norm_name(value):
    return ' '.join(str(value or '').strip().lower().split())


data = json.loads(DATA_PATH.read_text(encoding='utf-8'))
with MASTER_CSV.open(encoding='utf-8-sig', newline='') as f:
    master_rows = list(csv.DictReader(f))

old_schools = data['schools']
by_id = {}
by_name = {}
for school in old_schools:
    by_id.setdefault(norm_id(school['schoolEsis']), []).append(school)
    by_name.setdefault(norm_name(school['schoolName']), []).append(school)

new_schools = []
matched_old_ids = set()
for row in master_rows:
    master_id = row['eSIS_School'].strip()
    master_name = row['School Name'].strip()
    candidates = by_id.get(norm_id(master_id), [])
    if len(candidates) != 1:
        candidates = by_name.get(norm_name(master_name), [])
    if len(candidates) > 1:
        raise RuntimeError(f'Ambiguous nomination match for {master_id} - {master_name}')
    matched = candidates[0] if candidates else None
    if matched:
        matched_old_ids.add((matched['schoolEsis'], matched['schoolName']))
    new_schools.append({
        'schoolEsis': master_id,
        'schoolName': master_name,
        'schoolType': row['School Type'].strip(),
        'region': row['Region'].strip(),
        'teachers': matched.get('teachers', []) if matched else [],
    })

unmatched = [s for s in old_schools if (s['schoolEsis'], s['schoolName']) not in matched_old_ids]
if unmatched:
    raise RuntimeError('Nominated schools missing from master school list: ' + '; '.join(f"{s['schoolEsis']} - {s['schoolName']}" for s in unmatched))

sources = list(data.get('generatedFrom', []))
if 'schools (46).csv' not in sources:
    sources.append('schools (46).csv')
data['generatedFrom'] = sources
data['schools'] = new_schools
data['schoolListSummary'] = {
    'totalSchools': len(new_schools),
    'schoolsWithNominations': sum(bool(s['teachers']) for s in new_schools),
    'schoolsWithoutNominations': sum(not s['teachers'] for s in new_schools),
}
DATA_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps(data['schoolListSummary']))
